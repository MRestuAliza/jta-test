import Image from "next/image";
import Landing from "./Landing";

export default function Home() {
  return (
    <>
      <Landing />
    </>
  );
}
