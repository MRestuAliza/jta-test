import { getToken } from "next-auth/jwt";
import { NextResponse } from "next/server";

export async function middleware(req) {
  const secret = process.env.SECRET;
  const token = await getToken({ req, secret });
  const { pathname } = req.nextUrl;

  if (token?.role === 'Mahasiswa') {
    const allowedPaths = [
      '/mahasiswa/dashboard',
      '/mahasiswa/saran',
      '/saran/board',
      '/mahasiswa/saran/board',
      '/mahasiswa/saran/saran'
    ];

    const isAllowedPath = allowedPaths.some(path => pathname.startsWith(path));
    
    if (isAllowedPath) {
      return NextResponse.next();
    }
    
    return NextResponse.redirect(new URL('/mahasiswa/dashboard', req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/',
    '/login',
    '/register',
    '/dashboard',
    '/mahasiswa/:path*',
    '/saran/:path*',
    '/api/:path*', // Catch all API routes
  ],
};